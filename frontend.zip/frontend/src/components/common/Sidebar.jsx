import FFSvg from "../svgs/FF"; // Import custom SVG logo for the sidebar

import { MdHomeFilled } from "react-icons/md"; // Home icon from react-icons
import { IoNotifications } from "react-icons/io5"; // Notifications icon from react-icons
import { FaUser } from "react-icons/fa"; // User profile icon from react-icons
import { Link } from "react-router-dom"; // Link for navigation
import { BiLogOut } from "react-icons/bi"; // Logout icon from react-icons

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"; // TanStack Query for managing server state
import toast from "react-hot-toast"; // Toast notifications for success/error feedback

const Sidebar = () => {

	// QueryClient instance to invalidate queries
	const queryClient = useQueryClient();

	// Mutation to handle user logout
	const { mutate: logout } = useMutation({
		mutationFn: async () => {
			try {
				const res = await fetch("/api/auth/logout", {
					method: "POST", // API call to logout user
				});
				const data = await res.json();
				if (!res.ok) throw new Error(data.error || "Logout Failed"); // Handle API errors
				return data; // Return the response data
			} catch (error) {
				throw new Error(error); // Pass the error to the mutation
			}
		},
		onSuccess: () => {
			// Show success toast and invalidate the "authUser" query
			toast.success("Logout successful");
			queryClient.invalidateQueries({ queryKey: ["authUser"] });
		},
		onError: () => {
			// Show error toast on logout failure
			toast.error("Logout failed");
		},
	});

	// Query to fetch the authenticated user
	const { data: authUser } = useQuery({
		queryKey: ["authUser"], // Unique key for caching and refetching user data
	});

	return (
		<div className='md:flex-[2_2_0] w-18 max-w-52'>
			{/* Sidebar container */}
			<div className='sticky top-1 left-0 h-screen flex flex-col border-r border-gray-700 w-20 md:w-full'>
				{/* Logo */}
				<Link to='/' className='flex justify-center md:justify-start'>
					<FFSvg className='px-2 w-12 h-12 rounded-full fill-soft-purple hover:bg-custom-purple' />
				</Link>
				{/* Navigation Links */}
				<ul className='flex flex-col gap-3 mt-4'>
					{/* Home Link */}
					<li className='flex justify-center md:justify-start'>
						<Link
							to='/'
							className='flex gap-3 items-center hover:bg-soft-purple transition-all rounded-full duration-300 py-2 pl-2 pr-4 max-w-fit cursor-pointer'
						>
							<MdHomeFilled className='w-8 h-8' /> {/* Home Icon */}
							<span className='text-lg hidden md:block'>Home</span>
						</Link>
					</li>
					{/* Notifications Link */}
					<li className='flex justify-center md:justify-start'>
						<Link
							to='/notifications'
							className='flex gap-3 items-center hover:bg-soft-purple transition-all rounded-full duration-300 py-2 pl-2 pr-4 max-w-fit cursor-pointer'
						>
							<IoNotifications className='w-6 h-6' /> {/* Notifications Icon */}
							<span className='text-lg hidden md:block'>Notifications</span>
						</Link>
					</li>
					{/* Profile Link */}
					<li className='flex justify-center md:justify-start'>
						<Link
							to={`/profile/${authUser?.username}`} // Dynamically link to the user's profile
							className='flex gap-3 items-center hover:bg-soft-purple transition-all rounded-full duration-300 py-2 pl-2 pr-4 max-w-fit cursor-pointer'
						>
							<FaUser className='w-6 h-6' /> {/* Profile Icon */}
							<span className='text-lg hidden md:block'>Profile</span>
						</Link>
					</li>
				</ul>
				{/* Authenticated User Info */}
				{authUser && (
					<Link
						to={`/profile/${authUser.username}`} // Link to the authenticated user's profile
						className='mt-auto mb-10 flex gap-2 items-start transition-all duration-300 hover:bg-soft-purple py-2 px-4 rounded-full'
					>
						{/* User Avatar */}
						<div className='avatar hidden md:inline-flex'>
							<div className='w-8 rounded-full'>
								<img src={authUser?.profileImg || "/avatar-placeholder.png"} />
							</div>
						</div>
						{/* User Info and Logout Button */}
						<div className='flex justify-between flex-1'>
							<div className='hidden md:block'>
								<p className='text-custom-purple font-bold text-sm w-20 truncate'>{authUser?.fullName}</p>
								<p className='text-slate-500 text-sm'>@{authUser?.username}</p>
							</div>
							{/* Logout Button */}
							<BiLogOut
								className='w-5 h-5 cursor-pointer'
								onClick={(e) => {
									e.preventDefault(); // Prevent navigation
									logout(); // Trigger the logout mutation
								}}
							/>
						</div>
					</Link>
				)}
			</div>
		</div>
	);
};

export default Sidebar; // Export the Sidebar component
